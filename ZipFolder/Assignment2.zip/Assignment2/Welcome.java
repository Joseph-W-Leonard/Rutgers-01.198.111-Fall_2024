
/*
 * Write your program inside the main method that displays Welcome to CS111. 
 *
 * Note that it must include the period after CS111
 * 
 * To compile:
 *        javac Welcome.java
 * To execute:
 *        java Welcome
 * 
 * DO NOT change the class name
 * DO NOT use System.exit()
 * DO NOT change add import statements
 * DO NOT add project statement
 * 
 */

public class Welcome {

    public static void main(String[] args) {

	// WRITE YOUR CODE HERE

    }
}
